<x-app-layout>
    <x-slot name="header">
        <h2 class="font-semibold text-2xl md:text-3xl text-gray-800 dark:text-gray-200 leading-tight">
            {{ __('Estoque de Patrimônios') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="w-full sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">

                    {{-- Formulário de Filtro --}}
                    <div x-data="{ open: {{ !empty(array_filter(request()->query())) ? 'true' : 'false' }} }" class="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg mb-6">
                        <div @click="open = !open" class="flex justify-between items-center cursor-pointer">
                            <h3 class="font-semibold text-lg">Filtros de Busca</h3>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 transform transition-transform" :class="{'rotate-180': open}" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>
                        </div>
                        <div x-show="open" x-transition class="mt-4" style="display: none;">
                            <form method="GET" action="{{ route('patrimonios.index') }}">
                                <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                                    <input type="text" name="descricao" placeholder="Buscar por Descrição..." value="{{ request('descricao') }}" class="border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                                    <input type="text" name="situacao" placeholder="Buscar por Situação..." value="{{ request('situacao') }}" class="border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                                    <input type="text" name="modelo" placeholder="Buscar por Modelo..." value="{{ request('modelo') }}" class="border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                                    @if(Auth::user()->PERFIL === 'ADM')
                                    <select name="cadastrado_por" class="border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                                        <option value="">Todos os Usuários</option>
                                        @foreach($cadastradores as $cadastrador)
                                            <option value="{{ $cadastrador->CDMATRFUNCIONARIO }}" @selected(request('cadastrado_por') == $cadastrador->CDMATRFUNCIONARIO)>
                                                {{ $cadastrador->NOMEUSER }}
                                            </option>
                                        @endforeach
                                    </select>
                                    @endif
                                </div>
                                <div class="flex items-center mt-4">
                                    <x-primary-button>
                                        {{ __('Filtrar') }}
                                    </x-primary-button>
                                    <a href="{{ route('patrimonios.index') }}" class="ml-4 text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 rounded-md">
                                        Limpar Filtros
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    {{-- Botão de Cadastrar (sem o de exportar) --}}
                    <div class="flex justify-end mb-4">
                        <a href="{{ route('patrimonios.create') }}" class="bg-plansul-blue hover:bg-opacity-90 text-white font-bold py-2 px-4 rounded inline-flex items-center">
                             <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                               <path fill-rule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clip-rule="evenodd" />
                             </svg>
                             <span>Cadastrar Novo</span>
                        </a>
                    </div>
                    
                    <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                        <table class="w-full text-base text-left rtl:text-right text-gray-500 dark:text-gray-400">
                            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                @php
                                    function sortable_link($column, $label) {
                                        $direction = request('sort') === $column && request('direction') === 'asc' ? 'desc' : 'asc';
                                        return '<a href="'.route('patrimonios.index', array_merge(request()->query(), ['sort' => $column, 'direction' => $direction])).'">'.$label.'</a>';
                                    }
                                @endphp
                                <tr>
                                    <th scope="col" class="px-6 py-3">{!! sortable_link('NUPATRIMONIO', 'Nº Patrimônio') !!}</th>
                                    <th scope="col" class="px-6 py-3">{!! sortable_link('MODELO', 'Modelo') !!}</th>
                                    <th scope="col" class="px-6 py-3">{!! sortable_link('DEPATRIMONIO', 'Descrição') !!}</th>
                                    <th scope="col" class="px-6 py-3">{!! sortable_link('SITUACAO', 'Situação') !!}</th>
                                    <th scope="col" class="px-6 py-3">Cadastrado por</th>
                                    @if(Auth::user()->PERFIL === 'ADM')
                                        <th scope="col" class="px-6 py-3">Ações</th>
                                    @endif
                                </tr>
                            </thead>
                            <tbody>
                                @forelse ($patrimonios as $patrimonio)
                                <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                                    <td class="px-6 py-4">{{ $patrimonio->NUPATRIMONIO ?? 'N/A' }}</td>
                                    <td class="px-6 py-4">{{ $patrimonio->MODELO }}</td>
                                    <td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white">{{ $patrimonio->DEPATRIMONIO }}</td>
                                    <td class="px-6 py-4">{{ $patrimonio->SITUACAO }}</td>
                                    <td class="px-6 py-4">{{ $patrimonio->usuario?->NOMEUSER ?? 'Não informado' }}</td>
                                    @if(Auth::user()->PERFIL === 'ADM')
                                    <td class="px-6 py-4 flex items-center space-x-2">
                                        @can('update', $patrimonio)
                                            <a href="{{ route('patrimonios.edit', $patrimonio) }}" class="font-medium text-plansul-orange dark:text-orange-400 hover:underline">Editar</a>
                                        @endcan
                                        @can('delete', $patrimonio)
                                            <form method="POST" action="{{ route('patrimonios.destroy', $patrimonio) }}" onsubmit="return confirm('Tem certeza que deseja deletar este item?');">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="font-medium text-red-600 dark:text-red-500 hover:underline">Deletar</button>
                                            </form>
                                        @endcan
                                    </td>
                                    @endif
                                </tr>
                                @empty
                                <tr>
                                    <td colspan="{{ Auth::user()->PERFIL === 'ADM' ? 6 : 5 }}" class="px-6 py-4 text-center">Nenhum patrimônio encontrado para os filtros atuais.</td>
                                </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                     <div class="mt-4">
                        {{ $patrimonios->appends(request()->query())->links() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</x-app-layout>