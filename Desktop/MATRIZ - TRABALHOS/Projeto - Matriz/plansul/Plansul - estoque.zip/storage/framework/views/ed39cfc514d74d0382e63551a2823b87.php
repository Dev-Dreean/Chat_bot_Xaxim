<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-2xl md:text-3xl text-gray-800 dark:text-gray-200 leading-tight">
            <?php echo e(__('Estoque de Patrimônios')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="w-full sm:px-6 lg:px-8">
            <div class="bg-white dark:bg-gray-800 overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 dark:text-gray-100">

                    
                    <div x-data="{ open: <?php echo e(!empty(array_filter(request()->query())) ? 'true' : 'false'); ?> }" class="bg-gray-50 dark:bg-gray-700/50 p-4 rounded-lg mb-6">
                        <div @click="open = !open" class="flex justify-between items-center cursor-pointer">
                            <h3 class="font-semibold text-lg">Filtros de Busca</h3>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 transform transition-transform" :class="{'rotate-180': open}" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" /></svg>
                        </div>
                        <div x-show="open" x-transition class="mt-4" style="display: none;">
                            <form method="GET" action="<?php echo e(route('patrimonios.index')); ?>">
                                <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                                    <input type="text" name="descricao" placeholder="Buscar por Descrição..." value="<?php echo e(request('descricao')); ?>" class="border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                                    <input type="text" name="situacao" placeholder="Buscar por Situação..." value="<?php echo e(request('situacao')); ?>" class="border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                                    <input type="text" name="modelo" placeholder="Buscar por Modelo..." value="<?php echo e(request('modelo')); ?>" class="border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                                    <?php if(Auth::user()->PERFIL === 'ADM'): ?>
                                    <select name="cadastrado_por" class="border-gray-300 dark:border-gray-700 dark:bg-gray-900 dark:text-gray-300 focus:border-indigo-500 dark:focus:border-indigo-600 focus:ring-indigo-500 dark:focus:ring-indigo-600 rounded-md shadow-sm">
                                        <option value="">Todos os Usuários</option>
                                        <?php $__currentLoopData = $cadastradores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cadastrador): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($cadastrador->CDMATRFUNCIONARIO); ?>" <?php if(request('cadastrado_por') == $cadastrador->CDMATRFUNCIONARIO): echo 'selected'; endif; ?>>
                                                <?php echo e($cadastrador->NOMEUSER); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                    <?php endif; ?>
                                </div>
                                <div class="flex items-center mt-4">
                                    <?php if (isset($component)) { $__componentOriginald411d1792bd6cc877d687758b753742c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginald411d1792bd6cc877d687758b753742c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                                        <?php echo e(__('Filtrar')); ?>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $attributes = $__attributesOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__attributesOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginald411d1792bd6cc877d687758b753742c)): ?>
<?php $component = $__componentOriginald411d1792bd6cc877d687758b753742c; ?>
<?php unset($__componentOriginald411d1792bd6cc877d687758b753742c); ?>
<?php endif; ?>
                                    <a href="<?php echo e(route('patrimonios.index')); ?>" class="ml-4 text-sm text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100 rounded-md">
                                        Limpar Filtros
                                    </a>
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    
                    <div class="flex justify-end mb-4">
                        <a href="<?php echo e(route('patrimonios.create')); ?>" class="bg-plansul-blue hover:bg-opacity-90 text-white font-bold py-2 px-4 rounded inline-flex items-center">
                             <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                               <path fill-rule="evenodd" d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z" clip-rule="evenodd" />
                             </svg>
                             <span>Cadastrar Novo</span>
                        </a>
                    </div>
                    
                    <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                        <table class="w-full text-base text-left rtl:text-right text-gray-500 dark:text-gray-400">
                            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                                <?php
                                    function sortable_link($column, $label) {
                                        $direction = request('sort') === $column && request('direction') === 'asc' ? 'desc' : 'asc';
                                        return '<a href="'.route('patrimonios.index', array_merge(request()->query(), ['sort' => $column, 'direction' => $direction])).'">'.$label.'</a>';
                                    }
                                ?>
                                <tr>
                                    <th scope="col" class="px-6 py-3"><?php echo sortable_link('NUPATRIMONIO', 'Nº Patrimônio'); ?></th>
                                    <th scope="col" class="px-6 py-3"><?php echo sortable_link('MODELO', 'Modelo'); ?></th>
                                    <th scope="col" class="px-6 py-3"><?php echo sortable_link('DEPATRIMONIO', 'Descrição'); ?></th>
                                    <th scope="col" class="px-6 py-3"><?php echo sortable_link('SITUACAO', 'Situação'); ?></th>
                                    <th scope="col" class="px-6 py-3">Cadastrado por</th>
                                    <?php if(Auth::user()->PERFIL === 'ADM'): ?>
                                        <th scope="col" class="px-6 py-3">Ações</th>
                                    <?php endif; ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $patrimonios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patrimonio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-600">
                                    <td class="px-6 py-4"><?php echo e($patrimonio->NUPATRIMONIO ?? 'N/A'); ?></td>
                                    <td class="px-6 py-4"><?php echo e($patrimonio->MODELO); ?></td>
                                    <td class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"><?php echo e($patrimonio->DEPATRIMONIO); ?></td>
                                    <td class="px-6 py-4"><?php echo e($patrimonio->SITUACAO); ?></td>
                                    <td class="px-6 py-4"><?php echo e($patrimonio->usuario?->NOMEUSER ?? 'Não informado'); ?></td>
                                    <?php if(Auth::user()->PERFIL === 'ADM'): ?>
                                    <td class="px-6 py-4 flex items-center space-x-2">
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $patrimonio)): ?>
                                            <a href="<?php echo e(route('patrimonios.edit', $patrimonio)); ?>" class="font-medium text-plansul-orange dark:text-orange-400 hover:underline">Editar</a>
                                        <?php endif; ?>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $patrimonio)): ?>
                                            <form method="POST" action="<?php echo e(route('patrimonios.destroy', $patrimonio)); ?>" onsubmit="return confirm('Tem certeza que deseja deletar este item?');">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="font-medium text-red-600 dark:text-red-500 hover:underline">Deletar</button>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="<?php echo e(Auth::user()->PERFIL === 'ADM' ? 6 : 5); ?>" class="px-6 py-4 text-center">Nenhum patrimônio encontrado para os filtros atuais.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                     <div class="mt-4">
                        <?php echo e($patrimonios->appends(request()->query())->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\Users\marketing\Desktop\MATRIZ - TRABALHOS\Projeto - Matriz\plansul\resources\views/patrimonios/index.blade.php ENDPATH**/ ?>